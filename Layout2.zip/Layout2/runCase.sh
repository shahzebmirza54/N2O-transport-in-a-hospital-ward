#$ -S /bin/sh
#$ -cwd					#run in current working directory
#$ -j y
#$ -N efbCondDiff	    # Name of job
#$ -pe mpich 24     	# Number of CPUs
#$ -P OzelGroup			#  
##$ -l h=compute-0-15     #

# Libraries
source ~/.bashrc

# Source OF9+blastFoam
#unset FOAM_INST_DIR WM_PROJECT_SITE
export MPI_ROOT=/usr/local
export MPI_ARCH_FLAGS="-DOMPI_SKIP_MPICXX"
export MPI_ARCH_INC="-isystem $MPI_ROOT/include"
export MPI_ARCH_LIBS="-L$MPI_ROOT/lib -lmpi"

source /home/ao57/OpenFOAM/OpenFOAM-v2206/etc/bashrc

# Case folder
caseFolder=$PWD
#caseFolderName=$(basename $caseFolder)
caseFolderName=$(echo $caseFolder | awk -F "/" '{print $(NF-1)""$NF}')

# Go to tmp folder
cd /tmp
if [ ! -d $USER ]; then
  mkdir $USER
fi
cd $USER
if [ -d $caseFolderName ]; then
  rm -rf $caseFolderName
fi
#rsync -a $caseFolder .
mkdir $caseFolderName
rsync -a $caseFolder/ ./$caseFolderName/

# Go to case folder
cd $caseFolderName

# Run case 
blockMesh
topoSet
decomposePar -force
mpirun -n 24 rhoReactingFoam -parallel > logRun
reconstructPar
rm -rf proc*
foamToVTK

# Remove folder on node
cd ..
rsync -uavz ./$caseFolderName/ $caseFolder/
rm -rf $caseFolderName
